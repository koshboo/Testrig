import Config;
import time;
import sys;
import datetime
import redis;
import os;
from time import sleep;
from subprocess import Popen, PIPE, STDOUT;
import threading;
import signal;
import sqlite3;
#import ExpanderPi;
#from IOPi import IOPi
import Function;
from Function import set_heartbeat;
import pickle;
New_Dict = {};
##=========================================================================
##=================================DEC FUNCTION============================
##=========================================================================
##==================================detect E-Stop=========
def e_Stop():
	'''bus = IOPi(0x20);			
	if bus.read_pin(5) == 1:			# monitor E-stop pin
		Pipe = redis.Redis('Localhost');		
	 	Pipe.set ('E_STOP','Active');		# Set E-Stop in redis
	else:
		Pipe = redis.Redis('Localhost');	
	 	Pipe.delete ('E_STOP');			# Delete E-Stop 
'''	

##====================================================
def read_redis():
	Pipe = redis.Redis('Localhost');
	Mydict =dict();					# Create dictinary
	Mydict = Pipe.hgetall ('PIN_WRITE');		# Load 'PIN_Write' into the dict
	return (Mydict);
#======================================================

def write_redis (Mydict):
	global New_Dict;
	Pipe = redis.StrictRedis('Localhost');
	if (len(Mydict) > 0) : #Check if dict is empty
		for x,Val in Mydict.items():
			sp = x.split(',');		# split port/pin combo 
			Port = int(sp[1],16);		# assign port
			Pin = int (sp[0]);		# Assign pin	
			New_Dict [Port][Pin] = Val	# value to pin
			pd1 = New_Dict [Port]['Dir_Reg'] & 0x00ff  # Split reg value into 2 bytes
			pd2 = (New_Dict [Port]['Dir_Reg'] & 0xff00)>> 8

		for x,Val in New_Dict.items():			# cycle through ports
			p1 = 0;					# port 1 value reset
			p2 = 0;					# port 2 value reset
			New_Dict [x]['PB']= 0;			# reset port byte
			for e,w in Val.items():			# cycle through lvl 2 dict 
				if ((e != 'Dir_Reg') & (e != 'PB')): # ignore Dir reg and pb
					bit = 2**(int(e)-1)	# convert pin to bit
					if ((int (w) == 1)or(w == '1')):# if set high				
						New_Dict [x]['PB']= New_Dict [x]['PB'] + bit;# add bit to pb
					p1 = (New_Dict [x]['PB']) & 0x00ff# Split reg value into 2 bytes
					p2 = (int(New_Dict [x]['PB'] & 0xff00)) >> 8;		
			#bus = IOPi(Port);			# access i2c bus
			#bus.set_port_direction (0,pd1)		# set direction of port 1
			#bus.set_port_direction (1,pd2)		# set direction of port 2
			#bus.write_port (0,p1);
			#bus.write_port (1,p2)	
			print format (p1,'08b')
			print format (p2,'08b')				
	Pipe.hmset ('PIN_READ',Mydict);	
	time.sleep (1);
##===========================================================

def get_busses ():
	global New_Dict;						# import new dict
	Pipe = redis.Redis('Localhost');
        Pipe.delete ('PIN_WRITE');					# Delete old Pin_write on initalization
	Pipe.delete ('PIN_READ');					# Delete old Pin_read on initalization	
	Pipe = redis.Redis('Localhost');
	tmp = Pipe.get ('Ram');
	if tmp == None : Pipe.set ('Ram',0)
		
	conn = sqlite3.connect(Config.Connection,timeout = 60);		# Connect to sql
	cur = conn.cursor();
	cur.execute ('select distinct i2c_bus from buses');  		# get a list of the ports used in the database
	conn.commit();
	for row in cur:			        	 		# Cycle through port number 	
		Port = int(row[0],16)
		New_Dict [Port] = {};		  			# Create a new dict in new dict
		New_Dict [Port]['Dir_Reg'] = 0;				# Initalize the direction registry
	cur.execute ('select i2c_bus,i2c_pin,direction from buses'); 	# select bus,pin and direction of all pins
	conn.commit();	
	conn.close;					   		

	for row in cur:							# Cycle through the rows 
		bit = 0; 
		Port = int(row[0],16);				
		aPin = int (row[1]);	
		if (row[2] == 'Input'): 		
			bit = 2**(aPin-1);				# Convert pin to bit in reg		
			New_Dict[Port]['Dir_Reg'] = New_Dict[Port]['Dir_Reg']+ bit # add bit to reg
		PinDesc = str(aPin)+','+str (row[0]);               	# Create pin/bort combo
		Pipe.hset ('PIN_WRITE',PinDesc,0);		  	# Write pin/bus combo and temp val to redis 
	New_Dict[32]['Dir_Reg'] = New_Dict[32]['Dir_Reg']+4;		
	return ()

def Ram_INIT1():
	global New_Dict;
	Pipe = redis.Redis('Localhost');				# Access redis
	s = Pipe.get ('Ram');						# get ram key from redis
	test = (New_Dict [32]['Dir_Reg'] & 4)				# test condition of bit in reg		
	if s <> "0":							# if redis returns higher 0 then	
		New_Dict [32][3] = '1';					# set pin 3 to high	
	else: 	
		New_Dict [32][3] = '0';		
			
			
	return (1);
