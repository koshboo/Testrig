#-----------------------------------------GOD---------------------------------------
#The GOD program is used to update the  main DB also to monitor all other programs.
#God will
#	1. Check if active programs are running
#	2. Check if main interface & DEC are running 
#	3. Monitor programs and their count and targets 
#	
#The program will check Approx. every 15 seconds
#The program will update the DB every 2 minutes
#------------------------------------------------------------------------------------

import redis;					# Used to access Redis
import Function;				# Used to Access User functions
import Config;					# Configuration file
import sqlite3;					# used to access sqlite DB
import time;					# Time based functions
from subprocess import Popen, PIPE, STDOUT;	# Redis and other functions 
import sys;					# Standard system functions
from datetime import datetime,timedelta    

import sys;
sys.stdout = open(Config.Base+'Python/Logfiles/god.log', 'a+'); # redirect sysout to file
a = 0;
Pipe = redis.Redis('Localhost');		# Open pipe to redis 
l = Pipe.get ('GOD');				# get god key from redis if exists 	
newt = datetime.now() + timedelta(minutes = 2);	# set update timmer
if l <> None :					# check if god exists  				
	a = 1;					# set program for termination 
else:
 Function.set_heartbeat ('GOD','',20);		# set heartbeat
 while (a == 0):
	conn = sqlite3.connect(Config.Connection,timeout = 60);		# connect to sqlite DB
	cur = conn.cursor();						# Setup cursor
	cur.execute ('select ID,Target,count from programs where status = "Active"'); # select all active programs
	conn.commit(); 							# commit statement
	rows = cur.fetchall(); 						# fetchall results
	Function.set_heartbeat ('GOD','',20);  				# set heartbeat
	for row in rows:						# Cycle through results
		hold = str(row[0])					
		l = Function.get_active2 ('Active_program_'+hold);	# Check if program is regestered on redis 
		if (l == '') :						# if not start program	
			if (int (row[1]) - int (row[2]) > 0):		# Check if current count => Target
				Function.detached ('python',Config.Base+'Python/'+hold+'.py');
# start detached program the program will be the ID.py
				time.sleep(0.5);			# Sleep for 0.5 sec	
		else:
#if program is active
		   co = int (Pipe.hget ('Active_program_'+hold,'Count')); 	# get current count from redis
		   av =  float (Pipe.hget ('Active_program_'+hold,'AVG'));	# get avg cycle time
		   ta =  int (row[1]);						# Get target count		
		   Lef= ta - co;						# calc how many left
		   tot = int(Lef * av); 					# calc how long left
		   Pipe.hset ('Active_program_'+hold,'Target',ta); 		# Set target value in redis	
		   ending = datetime.now().replace(microsecond=0) + timedelta(seconds = int (tot)); # Calc ending
		   if datetime.now() > newt:					# should the DB be UPdated?
		 	try:
		   		cur.execute ('Update programs set EST_Finish_date = "'+str (ending)+'" where ID ="'+hold+'"');# if updating set est finish date
		  		conn.commit();					# commit change
				newt = datetime.now() + timedelta(minutes = 2);	# Add 2 mins to time	   
				cur.execute ('Update programs set count = "'+str (co)+'" where ID ="'+hold+'"');# set count in DB
		  		conn.commit();					#commit change
			except DatabaseError, e:
				print ('db error');				# raise on error
			finally:
				conn.close();					# close DB
		   	          		
		   if Lef <= 0 : 
			Pipe.hset ('Active_program_'+hold,'Status','Inactive'); # If target reached set program to inactive	
			
	#check if main interface is running
	l = Function.get_active ('INTERFACE');
	if (l == '') :
		Function.detached (Config.Base+'project1','');
		time.sleep(0.5);

	#check if main interface is running
	l = Function.get_active ('DEC');
	if (l == '') :
		Function.detached ('python','/home/pi/Desktop/application/Python/DEC.py');
		time.sleep(0.5);
	

	time.sleep(10)								#Sleep for 10 sec



