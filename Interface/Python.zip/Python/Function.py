import Config;
import time;
import sys;
import datetime
import redis;
import os;
from time import sleep;
from subprocess import Popen, PIPE, STDOUT;
import threading;
import signal;
import sqlite3;
#import ExpanderPi;
#from IOPi import IOPi
Activate = 0;



def signal_handler(sig, frame): # This detect a forced shutdown of the program and send the information to the log
	now = datetime.datetime.now();	
        print 'Program '+Config.Program_name+' FORCED STOP  ----------------'+now.strftime("%H:%M:%S");
	Pipe = redis.Redis('Localhost');
	tmp = int (Pipe.get ('Ram'));
	if tmp == None : tmp = 0;
	print tmp
	tmp = tmp - 1;
	Pipe.set ('Ram',tmp)
        sys.exit(0);

##========================================================================

def Set_up(filename):
	global Activate;
	s = filename.split ('.');		# split file name into name and extension
	Config.Program_name = s[0];		# Assign program_name as the name minus extension
	try:
				conn = sqlite3.connect(Config.Connection,timeout = 60); # Access sqlite DB
				cur = conn.cursor();	# Create cursor
				cur.execute ('select status from Programs where ID ='+Config.Program_name); # Execute command
				conn.commit();	
				re = cur.fetchone(); # fetch one result 
				test = re[0];	# transfer the data to a variable

	except DatabaseError, e:
				print ('db error'); # by viewing logs i will be able to identify how many db crashes i have
	finally:
				conn.close(); # final tash ALWAYS close the db connection 
	hold = 0;

	Pipe = redis.Redis('Localhost');	# open access to redis server
	l = Pipe.hget ('Active_program_'+Config.Program_name,'Count'); # attempt to get the count from the redis server
	if (l <> None) : hold = 1; # could we get the count from redis?
	if (test != 'Active') : hold = 2; # is the program on hold?
	if (hold > 0):		# if either of the above is true the program should abort.
		out = 0;
	else:			# the program is not running but should be
			Activate = 1;
			try:
				conn = sqlite3.connect(Config.Connection,timeout = 60);
				cur = conn.cursor();
				cur.execute ('select count from Programs where ID ='+Config.Program_name);
				conn.commit();
				re = cur.fetchone();
				Config.count = re[0];

			except DatabaseError, e:
				print ('db error');
			finally:
				conn.close();

			if Config.count is None : Config.count = 0; #Init Config.count 
			sys.stdout = open(Config.Base+'Python/Logfiles/'+s[0]+'.log', 'a+'); # redirect sysout to file
			out = 1;
			signal.signal(signal.SIGINT, signal_handler)# set kill signal handler
			now = datetime.datetime.now();	# get program start time
			Config.Cycle_then = now; 
			print 'Program '+Config.Program_name+' Start  ----------------'+now.strftime("%H:%M:%S"); # out put program start time
			set_heartbeat ('Active_program_'+Config.Program_name,Config.count,20) # init heartbeat for program
	return (out) # return final decision of start or stop

##=========================================================================
# Log data 
##=========================================================================
def Update (logging):

	ret = 1;
	now = datetime.datetime.now(); # time now
	Diff = datetime.datetime.now()-Config.Cycle_then; # get differenct between now & then
	Config.Cycle_then = now;
	Config.tot_cycle_time = Config.tot_cycle_time + Diff.total_seconds(); # Add difference to running count
	if (bool(logging & 1)): # if cycle time logging enabled?
		F = open(Config.Base+'Python/Logfiles/'+Config.Program_name+'.CYC', 'a+');
		F.write ('Cycle Time '+str(Diff)+'\r\n');# add cycle time to log file
		F.close;
	
	if (bool(logging & 2)): # is temprature to be logged
		F = open(Config.Base+'Python/Logfiles/'+Config.Program_name+'.Tem', 'a+');
		F.write ('TEMP - N/A \r\n'); # add temp to log
		F.close;

	Config.Cycle_then = now;
	
	set_heartbeat ('Active_program_'+Config.Program_name,Config.count,10);# send heartbeat to redis
	Config.count = Config.count + 1; #  up the count 
	Config.avg_count = Config.avg_count + 1;
	Config.avg_cycle_time = Config.tot_cycle_time / Config.avg_count; # get avg cycle time
	test = '';
	if Config.count >= Config.target:
		ret = 4;
	while True:
		try:
				conn = sqlite3.connect(Config.Connection,timeout = 60);
				cur = conn.cursor();
				cur.execute ('select status from Programs where ID ='+Config.Program_name); #get status from sql
				conn.commit();
				re = cur.fetchone();
				test = re[0];

		except DatabaseError, e:
				print ('db error');
		finally:
				conn.close();
		if test == 'Active' : break; # if active then carry on
		if test == 'Completed' : 	# if completed then set ret to 4
			ret = 4;
			break;
		time.sleep(1);	# if set to paused then wait do not continue recheck every second
   	return (ret);


##=========================================================================
# This is used for any operation where a switch is the end trigger
##=========================================================================
def Switched (Pin,Direction,Switch,State):
   time.sleep (0.5);				# sleep 1/2 second debounce
   Pipe = redis.Redis('Localhost');		
   Pipe.hset ('PIN_WRITE',Pin,Direction);	# write to redis 
   s = Pipe.hget ('PIN_READ',Switch);		
   then = datetime.datetime.now(); 
   err = 0;
   while (s != str(State)):			# wait until redis DEC reports that it has changed the pin
	time.sleep(0.2);	 		# Keep checking every 0.2 sec
	s = Pipe.hget ('PIN_READ',Switch);	
	now = datetime.datetime.now();
	diff = (now - then).total_seconds();
	
	if diff > 5 : 				# maintain heartbeat while waiting
		set_heartbeat ('Active_program_'+Config.Program_name,Config.count,10);
		then = datetime.datetime.now();
   Pipe = redis.Redis('Localhost');
   s = Pipe.get ('E_STOP');			# check for E-stop 
   while s == 'Active':			# loop while e-stop is pressed.
		time.sleep(1);
		s = Pipe.get ('E_STOP');
		set_heartbeat ('Active_program_'+Config.Program_name,Config.count,10);# maintain heartbeat while waiting

   return (err);

##=========================================================================
# This is used for any operation where a time is the end trigger
# The timer is not started until PIN_READ corisponds to the selected state 
##=========================================================================
def Timed (Pin,Direction,Time):
   Pipe = redis.Redis('Localhost');
   Pipe.hset ('PIN_WRITE',Pin,Direction);	# write command to redis
   s = Pipe.hget ('PIN_READ',Pin);		# read pin 
   then = datetime.datetime.now();	
   while (s != str(Direction)):			# Check if read = write
	sleep(1);
				# sleep 0.1 seconds
	s = Pipe.hget ('PIN_READ',Pin);		# read redis for pin state
	now = datetime.datetime.now();
	diff = (now - then).total_seconds();
	if diff > 5 : 				# maintain heart beat while waiting for pin to change
		set_heartbeat ('Active_program_'+Config.Program_name,Config.count,10);
		then = datetime.datetime.now();
   while Time > 0:
	if Time > 5:
		sleep (5);	
		set_heartbeat ('Active_program_'+Config.Program_name,Config.count,10); # Maintain heartbeat
		Time = Time - 5;
	else:
		sleep (Time);
		Time = 0;
  
   Pipe = redis.Redis('Localhost');
   s = Pipe.get ('E_STOP');	# check for E-stop
   while s == 'Active':	# loop while e-stop is pressed
		time.sleep(1);
		s = Pipe.get ('E_STOP'); #check estop
		set_heartbeat ('Active_program_'+Config.Program_name,Config.count,10);# Maintain heartbeat
   return (1);

##===================defunct ???===========================================

def get_status():
	ret=1
	Pipe = redis.Redis('Localhost');
	l = Pipe.hget('Active_program_'+Config.Program_name,'Status');
	if l == 'Inactive':
		ret = 0;
	return (ret)

##=========================================================================

def Ram_INIT():
 global Activate;
 if Activate > 0:
	Pipe = redis.Redis('Localhost');
	tmp = int (Pipe.get ('Ram'));
	print ('hello')
	 
	if tmp == None : tmp = 0;
	print tmp
	tmp = tmp + 1;
	Pipe.set ('Ram',tmp)

##=========================================================================
#check if water has run for the correct time on/off
#def Water_check (on,off):
#	now = datetime.datetime.now()
#	# check if the water cycle has been started
#	if (Config.water_active == 0):
#		Config.water_active = 2;
#		Config.water_track = time.time()-(60);
#		
#
#	# Check if selected time has passed
#	if (time.time() >= Config.water_track):
#		if (Config.water_active == 2):
#		        Config.water_active = 1;
#			Config.water_track = time.time()+ (on*60);
#
#			bus = IOPi(0x20);	
 #  			bus.write_pin(1,1) ;	# turn on relay to activate water
#			time.sleep (0.5);	# hold relay active for 0.5 secs
#			bus.write_pin(1,0) ;	# turn off relay
#			print 'Water on '+now.strftime("%Y-%m-%d %H:%M");
#		
#		elif(Config.water_active == 1):	
#			bus = IOPi(0x20);	
 #  			bus.write_pin(2,1);	# turn on relay to deactivate water
#			time.sleep (0.5);	# hold relay active for 0.5 secs
#			bus.write_pin(2,0);	# turn off relay
#	
#			Config.water_active = 2;
#			Config.water_track = time.time()+ (off*60);
#			print 'Water off '+now.strftime("%Y-%m-%d %H:%M"); 
##=========================================================================
def set_heartbeat (Name,Value,sec):
	
	Pipe = redis.Redis('Localhost');
	if "Active_program_" in Name:
		
		Pipe.hset (Name,'Count',Value);
		l = str ("%.1f" % round(Config.avg_cycle_time,1))
		Pipe.hset (Name,'AVG',l);
	else:
		
		Pipe.set (Name,0);
	Pipe.expire (Name,sec);

##=========================================================================
 
##=========================================================================
##=================================GOD FUNCTIONS
===========================
##=========================================================================

def get_active2(Name):		#returns the value of a key using HGet
	s = 'Active';				
	Pipe = redis.Redis('Localhost');
	l = Pipe.hget (Name,'AVG');
	if l == None :	
		s ='';
	return s;

def get_active(Name):		# returns value of a key using get
	s = 'Active';
	Pipe = redis.Redis('Localhost');
	l = Pipe.get (Name);
	if l == None :	
		s ='';
	return s;
##=========================================================================

def detached (cmd,cmd2):
  fn=Config.Base+'Python/ssem';			# create filename
  sh =[];
  err =os.path.splitext(cmd2)[0]+ '.err';	# create error log file name
  log =os.path.splitext(cmd2)[0]+ '.log';	# create log filename
	
  sh.append(cmd+' '+cmd2+' 2>> '+Config.Base+'Python/Logfiles/'+os.path.basename(err)+' &'); # add commands
  sh.append('disown');	
  sh.append('exit');
  with open(fn, 'w') as filehandle:  
    for listitem in sh:				# loop through list adding the lines to the file
        filehandle.write('%s\n' % listitem)

  cmd = ['/bin/bash',fn];			# trigger a bash command to run the file
  f = open ('god.err','w+');			# redirect errors to file
  p = Popen(cmd,stderr=f);
  time.sleep (0.5);
  filehandle.close;
  os.remove(str(fn)); 				# remove file from file system

		
		 
