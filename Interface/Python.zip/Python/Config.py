
Connection = '/home/aron/Documents/application/Main.db'#'/home/pi/Desktop/application/Main.db';
Base = '/home/aron/Documents/application/'#'/home/pi/Desktop/application/';

water_time_out = 0;
water_time_in = 0;
water_active = 0;
water_track = 0;

Cycle_then = 0;

Program_name ='';
#program data
avg_cycle_time=0;
tot_cycle_time=0;
avg_count = 0;
count = int (0);
target = 100000000;

av_buses =[];

