import Function;
import DEC_Functions;
import time;
import Config;
import sys;
#sys.stdout = open(Config.Base+'Python/Logfiles/DEC.log', 'a+'); # redirect sysout to file
DEC_Functions.get_busses();
while (1):
	Dict = DEC_Functions.read_redis();
	DEC_Functions.write_redis (Dict);
	DEC_Functions.set_heartbeat ('DEC','',10);
	DEC_Functions.e_Stop();
	DEC_Functions.Ram_INIT1();
	time.sleep(0.1)

