from Function import *;
import time; 
import os;
import Config;
from datetime import datetime
Log = 0;
ram_1 = "1,0x20"
Bay_1 = "9,0x26"
Out = 1;
In  = 0;
Active = 1;
Inactive = 0;
## Setup Variables
c = 1; 
c = Set_up(os.path.basename(__file__))
Ram_INIT()

while (c == 1):
 
    Timed (Bay_1,Out,2);
    Timed (ram_1,Out,2);
    Timed (ram_1,In,2);
    Timed (Bay_1,In,2);
    c = Update(Log);
if (c == 4):
	print 'Program '+Config.Program_name+' Completed ----------------'+datetime.now().strftime("%H:%M:%S");
else:
	print 'Program '+Config.Program_name+' commanded to STOP ----------------'+datetime.now().strftime("%H:%M:%S");
