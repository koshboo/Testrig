import Function;
import sqlite3;
import Config;


conn = sqlite3.connect(Config.Connection,timeout = 60);
cur = conn.cursor();
c = 32;
a = 20
p = 1;
while c < 39:
   print c	
   while p < 17: 
	if c <> 33:
		bus = str('0x'+str(a));
		l = str(p)
	 	cur.execute ('insert into Buses (bus,pin,i2c_bus,i2c_pin,direction,inuse) values (1,1,"'+ bus +'",'+ l +',"Output",0)');
		conn.commit();
	p = p + 1;	
   c = c + 1;
   a = a + 1;
   p = 1;
			
