from Function import *;
import time; 
import os;
import Config;
from datetime import datetime
## Setup Constants
Out = 1;
In  = 0;
Active = 1;
Inactive = 0;
## Setup Variables
c = 1; 
c = Set_up(os.path.basename(__file__))
## Start of Program

while (c == 1):

    
    c = Update(Log);
if (c == 4):
	print 'Program '+Config.Program_name+' Completed ----------------'+datetime.now().strftime("%H:%M:%S");
else:
	print 'Program '+Config.Program_name+' commanded to STOP ----------------'+datetime.now().strftime("%H:%M:%S");
