import Config;
import time;
import sys;
import datetime
import redis;
import os;
from subprocess import Popen, PIPE, STDOUT;
import threading;
import signal;
import sqlite3;
import ExpanderPi;
from IOPi import IOPi

bus = IOPi (0x20);
bus.set_pin_direction (1,0)
while True:
	bus.write_pin (1,1);
	time.sleep(1);
	bus.write_pin (1,0);
	time.sleep(1);

