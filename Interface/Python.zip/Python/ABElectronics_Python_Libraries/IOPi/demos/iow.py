#!/usr/bin/env python

"""
================================================
ABElectronics IO Pi | Digital I/O Write Demo

Requires python smbus to be installed
For Python 2 install with: sudo apt-get install python-smbus
For Python 3 install with: sudo apt-get install python3-smbus

run with: python demo_iowrite.py
================================================

This example uses the write_pin and write_port methods to switch the pins
on and off on the I/O bus.

"""
from __future__ import absolute_import, division, print_function, \
                                                    unicode_literals
import time

try:
    import ExpanderPi	
    from IOPi import IOPi
except ImportError:
    print("Failed to import IOPi from python system path")
    print("Importing from parent folder instead")
    try:
        import sys
        sys.path.append('..')
        from IOPi import IOPi
    except ImportError:
        raise ImportError(
            "Failed to import library from parent folder")


def main():
    '''
    Main program function
    '''

    # Create an instance of the IOPi class with an I2C address of 0x20
    iobus = IOPi(0x20)
  
    # We will write to the pins 9 to 16 so set port 1 to be outputs turn off
    # the pins
    iobus.set_port_direction(0, 0x00)
 	
    iobus.write_pin(3, 1)	
    while True:	
      iobus = IOPi(0x26)# step out
      iobus.set_port_direction(0, 0x00)
      iobus.write_pin(1, 1)
      print ('s out');
      time.sleep(3)
     
      iobus = IOPi(0x20)
      iobus.set_port_direction(0, 0x00)
      iobus.write_pin(2, 1)	#ram out	
      time.sleep(5)

      iobus.write_pin(2, 0)#	ram in
      time.sleep(1)
      iobus = IOPi(0x26)
      iobus.set_port_direction(0, 0x00)
      iobus.write_pin(1, 0) #step in
      time.sleep(5)	      
  # repeat until the program ends

if __name__ == "__main__":
    main()
