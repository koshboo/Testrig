#!/usr/bin/env python

"""
================================================
ABElectronics Expander Pi | Digital I/O Write Demo

Requires python smbus to be installed
For Python 2 install with: sudo apt-get install python-smbus
For Python 3 install with: sudo apt-get install python3-smbus

run with: python demo_iowrite.py
================================================

This example uses the write_pin and writeBank methods to switch the pins
on and off on the I/O bus.

"""
from __future__ import absolute_import, division, print_function, \
                                                    unicode_literals
import time

try:
    import ExpanderPi
except ImportError:
    print("Failed to import ExpanderPi from python system path")
    print("Importing from parent folder instead")
    try:
        import sys
        sys.path.append('..')
        import ExpanderPi
    except ImportError:
        raise ImportError(
            "Failed to import library from parent folder")


def main():
    '''
    Main program function
    '''
    iobus = ExpanderPi.IO()

    # We will write to the pins 9 to 16 so set port 1 to be outputs turn off
    # the pins
    iobus.set_port_direction(0, 0x00)
    iobus.write_port(0, 0x00)

    while True:

  

        # turn off all of the pins on bank 1
        
	iobus.write_pin(3, 1)

        # now turn on all of the leds in turn by writing to one pin at a time
        iobus.write_pin(1, 1)
        time.sleep(2)
        iobus.write_pin(1, 0)
  	time.sleep(2)
        

        # repeat until the program ends

if __name__ == "__main__":
    main()
